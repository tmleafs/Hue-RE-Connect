# the Cube

This a a nifty use of the smartsense Mutlisensor. Stuck it in a wooden box and you can trigger actions by rotating it!

<img src="https://dl.dropboxusercontent.com/u/2663552/Github/Smartthings/theCube/IMG_0758.jpg" width="100px">

Each face can trigger a Smarthings routine.

## How it looks

SmartApp

<img src="https://dl.dropboxusercontent.com/u/2663552/Github/Smartthings/theCube/IMG_0780.jpg" width="300px">

Face configuration

<img src="https://dl.dropboxusercontent.com/u/2663552/Github/Smartthings/theCube/IMG_0779.jpg" width="300px">
